from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.action_chains import ActionChains
import time
driver=webdriver.Chrome(service=Service(ChromeDriverManager().install()))
driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login")
time.sleep(2)
driver.find_element(By.CSS_SELECTOR,"[placeholder='Username']").send_keys('Admin')
time.sleep(3)
driver.find_element(By.CSS_SELECTOR,"[placeholder='Password']").send_keys('admin123')
time.sleep(3)
driver.find_element(By.CSS_SELECTOR,"button[type='submit']").click()
time.sleep(3)
driver.find_element(By.LINK_TEXT,"Claim").click()
time.sleep(2)
ref=driver.find_element(By.XPATH,"(//input[@placeholder='Type for hints...'])[2]")
time.sleep(2)
action=ActionChains(driver)
action.click(ref).perform()
time.sleep(2)
action.send_keys("111111111111111111111111111111111111").perform()
driver.find_element(By.XPATH,"//*[@type='submit']").click()
time.sleep(5)


